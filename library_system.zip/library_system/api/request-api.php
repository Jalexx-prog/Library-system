<?php
require_once("../include/db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ... (Your existing code for handling request submissions)

} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Handle request confirmation
    $requestData = json_decode(file_get_contents('php://input'), true);

    if (isset($requestData['request_id'])) {
        $requestId = $requestData['request_id'];

        // Assuming you have a column named 'confirmed' in your 'request_book' table
        $sql = "UPDATE `request_book` SET `confirmed` = 1 WHERE `id` = ?";
        $stmt = mysqli_prepare($con, $sql);

        mysqli_stmt_bind_param($stmt, "i", $requestId); // Assuming 'id' is an integer

        if (mysqli_stmt_execute($stmt)) {
            $response = array('status' => 'success', 'message' => 'Request confirmed successfully');
        } else {
            $response = array('status' => 'error', 'message' => 'Error confirming the request', 'error' => mysqli_error($con));
        }

        mysqli_stmt_close($stmt);
    } else {
        $response = array('status' => 'error', 'message' => 'Missing required field: request_id');
    }

    header('Content-Type: application/json');
    http_response_code($response['status'] === 'success' ? 200 : 400); // OK or Bad Request
    echo json_encode($response);

} else {
    header("HTTP/1.0 405 Method Not Allowed");
    exit();
}

function validateStudentData($name, $id) {
    return !empty($name) && !empty($id);
}

function validateBookData($name) {
    return !empty($name);
}
?>
