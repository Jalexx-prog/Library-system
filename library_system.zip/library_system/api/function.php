<?php 
require_once("../include/db.php");



function error422($message){
    $data = [
        'status' => 422,
        'message' => $message
    ];
    header("HTTP/1.0 405 Unproccessable Entity");
    echo json_encode($data);
    exit();
}


function getBookList() {

    global $con;

    $query = "SELECT * FROM books";
    $query_run = mysqli_query($con, $query);

    if($query_run) {
        if(mysqli_num_rows($query_run) > 0) {

            $res = mysqli_fetch_all($query_run, MYSQLI_ASSOC);

            $data = [
                'status' => 200,
                'message' => 'Book List Fetch Succesfully',
                'data' => $res
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);

        }else {
            $data = [
                'status' => 404,
                'message' => 'No Books Found',
            ];
            header("HTTP/1.0 404 No Books Found");
            return json_encode($data);

        }

    }
    else {
        $data = [
            'status' => 500,
            'message' => 'Method Not Allowed',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }

}

function getBooks($booksParams) {
    global $con;

    $conditions = [];

    if (!empty($booksParams['id'])) {
        $book_id = mysqli_real_escape_string($con, $booksParams['id']);
        $conditions[] = "id = '$book_id'";
    }

    if (!empty($booksParams['book_name'])) {
        $book_name = mysqli_real_escape_string($con, $booksParams['book_name']);
        $conditions[] = "book_name LIKE '%$book_name%'";
    }

    if (!empty($booksParams['book_author'])) {
        $book_author = mysqli_real_escape_string($con, $booksParams['book_author']);
        $conditions[] = "book_author LIKE '%$book_author%'";
    }

    if (empty($conditions)) {
        return error422('Enter book id, book_name, or book_author');
    }

    $whereClause = implode(' AND ', $conditions);

    $query = "SELECT * FROM books WHERE $whereClause";
    $result = mysqli_query($con, $query);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $res = mysqli_fetch_all($result, MYSQLI_ASSOC);
            $data = [
                'status' => 200,
                'message' => 'Books fetch successful',
                'data' => $res
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No books found',
            ];
            header("HTTP/1.0 404 Not Found");
            return json_encode($data);
        }
    } else {
        $data = [
            'status' => 500,
            'message' => 'Method Not Allowed',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }
}


function createBook($bookData) {
    global $con;

    
    $requiredFields = ['book_name', 'book_image', 'book_author', 'book_quantity', 'book_available', 'librian_name'];
    foreach ($requiredFields as $field) {
        if (!isset($bookData[$field]) || empty($bookData[$field])) {
            $data = [
                'status' => 422,
                'message' => "Missing or empty required field: $field",
            ];
            header("HTTP/1.0 422 Unprocessable Entity");
            return json_encode($data);
        }
    }

    
    $bookName = mysqli_real_escape_string($con, $bookData['book_name']);
    $bookImage = mysqli_real_escape_string($con, $bookData['book_image']);
    $bookAuthor = mysqli_real_escape_string($con, $bookData['book_author']);
    $bookQuantity = mysqli_real_escape_string($con, $bookData['book_quantity']);
    $bookAvailable = mysqli_real_escape_string($con, $bookData['book_available']);
    $librarianName = mysqli_real_escape_string($con, $bookData['librian_name']);

    
    $query = "INSERT INTO books (book_name, book_image, book_author, book_quantity, book_available, librian_name) 
              VALUES ('$bookName', '$bookImage', '$bookAuthor', '$bookQuantity', '$bookAvailable', '$librarianName')";
    
    $result = mysqli_query($con, $query);

    if ($result) {
        $data = [
            'status' => 201,
            'message' => 'Book Created Successfully',
        ];
        header("HTTP/1.0 201 Created");
        return json_encode($data);
    } else {
        $data = [
            'status' => 500,
            'message' => 'Internal Server Error',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }
}


function updateBook($bookInput, $bookParams)
{
    global $con;

    
    if (!isset($bookParams['id'])) {
        return error422('Book ID not found in the URL');
    }

    $book_id = mysqli_real_escape_string($con, $bookParams['id']);
    $book_name = mysqli_real_escape_string($con, $bookInput['book_name']);
    $book_author = mysqli_real_escape_string($con, $bookInput['book_author']);
    $book_quantity = mysqli_real_escape_string($con, $bookInput['book_quantity']);
    $book_available = mysqli_real_escape_string($con, $bookInput['book_available']);

    
    if (empty(trim($book_name)) || empty(trim($book_author)) || empty(trim($book_quantity)) || empty(trim($book_available))) {
        return error422('All fields must be filled');
    }

    
    $query = "UPDATE books SET book_name=?, book_author=?, book_quantity=?, book_available=? WHERE id=?";
    $stmt = mysqli_prepare($con, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ssssi', $book_name, $book_author, $book_quantity, $book_available, $book_id);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        if ($result) {
            $data = [
                'status' => 200,
                'message' => 'Book Updated Successfully',
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 500,
                'message' => 'Internal Server Error',
            ];
            header("HTTP/1.0 500 Internal Server Error");
            return json_encode($data);
        }
    } else {
        return error422('Failed to prepare SQL statement');
    }
}




function deleteBooks($bookParams) {
    global $con;

    if (!isset($bookParams['id'])) {
        return error422('book id not found in URL');
    } elseif (empty($bookParams['id'])) {
        return error422('Enter book id');
    }

    $bookId = mysqli_real_escape_string($con, $bookParams['id']);

    // Fetch book details before deleting
    $selectQuery = "SELECT * FROM books WHERE id='$bookId' LIMIT 1";
    $selectResult = mysqli_query($con, $selectQuery);
    
    if (!$selectResult) {
        $data = [
            'status' => 500,
            'message' => 'Error fetching book details',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }

    $bookDetails = mysqli_fetch_assoc($selectResult);

    // Delete from the original table
    $deleteQuery = "DELETE FROM books WHERE id='$bookId' LIMIT 1";
    $deleteResult = mysqli_query($con, $deleteQuery);

    if ($deleteResult) {
        if (mysqli_affected_rows($con) > 0) {
            // Insert into deleted_books table
            $insertQuery = "INSERT INTO deleted_books (id, book_name, book_image, book_author, book_quantity, book_available, librian_name) 
                            VALUES ('{$bookDetails['id']}', '{$bookDetails['book_name']}', '{$bookDetails['book_image']}', 
                                    '{$bookDetails['book_author']}', '{$bookDetails['book_quantity']}', '{$bookDetails['book_available']}', 
                                    '{$bookDetails['librian_name']}')";
            $insertResult = mysqli_query($con, $insertQuery);

            if (!$insertResult) {
                $data = [
                    'status' => 500,
                    'message' => 'Error moving book to deleted_books table',
                ];
                header("HTTP/1.0 500 Internal Server Error");
                return json_encode($data);
            }

            $data = [
                'status' => 200,
                'message' => 'Book Deleted Successfully',
            ];
            header("HTTP/1.0 200 OK");
            return json_encode($data);
        } else {
            $data = [
                'status' => 404,
                'message' => 'Book not found',
            ];
            header("HTTP/1.0 404 Not Found");
            return json_encode($data);
        }
    } else {
        $data = [
            'status' => 500,
            'message' => 'Internal Server Error',
        ];
        header("HTTP/1.0 500 Internal Server Error");
        return json_encode($data);
    }
}



?>