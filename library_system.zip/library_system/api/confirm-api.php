<?php

require_once("../include/db.php");

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if (isset($data['req_id']) && isset($data['book_id']) && isset($data['username'])) {
        $req_id = $data['req_id'];
        $book_id = $data['book_id'];
        $librarian_username = $data['username'];
        $date = date('m-d-Y');

        $sq = "SELECT students.id FROM students INNER JOIN request_book ON students.uid = request_book.student_id WHERE request_book.id = ?";
        $stmt = mysqli_prepare($con, $sq);
        mysqli_stmt_bind_param($stmt, "i", $req_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $ro = mysqli_fetch_assoc($result);

        if ($ro) {
            $std_id = $ro['id'];

            $sql = "INSERT INTO issue_book(student_id, book_id, lib_name, isssue_date) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($con, $sql);
            mysqli_stmt_bind_param($stmt, "iiss", $std_id, $book_id, $librarian_username, $date);
            $result = mysqli_stmt_execute($stmt);

            if ($result) {
                $sql = "UPDATE books SET book_available = book_available - 1 WHERE id = ?";
                $stmt = mysqli_prepare($con, $sql);
                mysqli_stmt_bind_param($stmt, "i", $book_id);
                $result = mysqli_stmt_execute($stmt);

                if ($result) {
                    $sql = "DELETE FROM request_book WHERE id = ?";
                    $stmt = mysqli_prepare($con, $sql);
                    mysqli_stmt_bind_param($stmt, "i", $req_id);
                    $result = mysqli_stmt_execute($stmt);

                    if ($result) {
                        $response = ['status' => 'success', 'message' => 'Request Book Successfully'];
                    } else {
                        $response = ['status' => 'error', 'message' => 'Error deleting request book record', 'code' => 500];
                    }
                } else {
                    $response = ['status' => 'error', 'message' => 'Error updating book availability', 'code' => 500];
                }
            } else {
                $response = ['status' => 'error', 'message' => 'Error issuing the book', 'code' => 500];
            }
        } else {
            $response = ['status' => 'error', 'message' => 'User ID not found', 'code' => 404];
        }
    } else {
        $response = ['status' => 'error', 'message' => 'Missing parameters', 'code' => 400];
        http_response_code(400);
    }
} else {
    $response = ['status' => 'error', 'message' => 'Invalid request method', 'code' => 405];
    http_response_code(405);
}

echo json_encode($response);
?>
