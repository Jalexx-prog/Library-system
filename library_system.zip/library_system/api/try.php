<?php
error_reporting(E_ALL);
session_start();

require_once("../include/db.php");

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if (isset($data['issue_id']) && isset($data['book_id'])) {
        $issue_id = $data['issue_id'];
        $book_id = $data['book_id'];

        $date = date('d-m-y');
        
        $sql = "UPDATE `issue_book` SET `return_date` = ? WHERE id = ?";
        $stmt = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($stmt, "si", $date, $issue_id);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            $sql = "UPDATE `books` SET `book_available` = `book_available` + 1 WHERE `id` = ?";
            $stmt = mysqli_prepare($con, $sql);
            mysqli_stmt_bind_param($stmt, "i", $book_id);
            $result = mysqli_stmt_execute($stmt);

            if ($result) {
                $response = ['status' => 'success', 'message' => 'Book returned successfully'];
            } else {
                $response = ['status' => 'error', 'message' => 'Error updating book availability'];
            }
        } else {
            $response = ['status' => 'error', 'message' => 'Error updating return date'];
        }
    } else {
        $response = ['status' => 'error', 'message' => 'Missing parameters'];
        http_response_code(400);
    }
} else {
    $response = ['status' => 'error', 'message' => 'Invalid request method'];
    http_response_code(405);
}

echo json_encode($response);
?>
