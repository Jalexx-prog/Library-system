<?php

require_once("../include/db.php");
error_reporting(0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Handle the API request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    // Check if required parameters are present in the request
    if (isset($data['student_name']) && isset($data['student_id']) && isset($data['book_id']) && isset($data['book_name'])) {
        $student_name = $data['student_name'];
        $student_id = $data['student_id'];
        $book_id = $data['book_id'];
        $book_name = $data['book_name'];

        // Check if the student has already borrowed the same book
        $checkSql = "SELECT * FROM `request_book` WHERE `student_id` = '$student_id' AND `book_id` = '$book_id'";
        $checkResult = mysqli_query($con, $checkSql);
        $existingRecord = mysqli_fetch_assoc($checkResult);

        if ($existingRecord) {
            $response = ['status' => 'error', 'message' => 'This book has already been requested by the student'];
        } else {
            // Insert the book request into the request_book table
            $sql = "INSERT INTO `request_book` (`student_name`, `student_id`, `book_id`, `book_name`) 
                    VALUES ('$student_name', '$student_id', '$book_id', '$book_name')";
            $result = mysqli_query($con, $sql);

            if ($result) {
                $response = ['status' => 'success', 'message' => 'Book request submitted successfully'];
            } else {
                $response = ['status' => 'error', 'message' => 'Failed to submit book request'];
            }
        }
    } else {
        
        $response = ['status' => 'error', 'message' => 'Missing parameters'];
        http_response_code(400); 
    }
} else {
    
    $response = ['status' => 'error', 'message' => 'Invalid request method'];
    http_response_code(405); 
}
echo json_encode($response);
?>
