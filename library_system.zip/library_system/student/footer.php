</div>
                <!--scroll to top-->
                <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
            </div>
        </div>
        <!--BASIC scripts-->
        <!-- ========================================================= -->
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="../assets/vendor/jquery/jquery-1.12.3.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="../assets/vendor/nano-scroller/nano-scroller.js"></script>
        <!--TEMPLATE scripts-->
        <!-- ========================================================= -->
        <script src="../assets/javascripts/template-script.min.js"></script>
        <script src="../assets/javascripts/template-init.min.js"></script>
        <!-- SECTION script and examples-->
        <!-- ========================================================= -->
        <!--Notification msj-->
        
        <!--morris chart-->
        <script src="../assets/vendor/chart-js/chart.min.js"></script>
        <!--Gallery with Magnific popup-->
        <script src="../assets/endor/magnific-popup/jquery.magnific-popup.min.js"></script>
        <!--Examples-->
        <script src="../assets/javascripts/examples/dashboard.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="https://cdn.lordicon.com/lordicon.js"></script>
        
        
    </body>

</html>