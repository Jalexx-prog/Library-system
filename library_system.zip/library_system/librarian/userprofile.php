
<?php 
require_once 'header.php'; 
$id = $_SESSION['admin_success_id'];
$sql = "SELECT * FROM libraian WHERE id = $id";
$result = mysqli_query($con,$sql);
$data = mysqli_fetch_assoc($result);
?>
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            <li><a href="#">My Profile</a></li>
        </ul>
    </div>
</div>    
<div class="row animated fadeInUp">
    <div class="col-md-6 col-lg-4">
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
        <!--PROFILE-->
        <div>
            <div class="profile-photo">
                <img alt="User photo" src="../images/libraian/<?= $data['image']?>">
            </div>
            <div class="user-header-info">
                <h2 class="user-name"><?= $data['name']?></h2>
                <h5 class="user-position" ><?= $data['tag']?></h5>
                <div class="user-social-media" style="margin-top: -3px;">
                    <span class="text-lg"><a href="#" class="fa fa-twitter-square"></a> <a href="https://www.facebook.com/inuffsaid.me" class="fa fa-facebook-square"></a> <a href="#" class="fa fa-linkedin-square"></a> <a href="#" class="fa fa-google-plus-square"></a></span>
                </div>
            </div>
        </div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
        <!--CONTACT INFO-->
        <div class="panel bg-scale-0 b-primary bt-sm mt-xl">
            <div class="panel-content">
                <h4 class=""><b>Contact Information</b></h4>
                <ul class="user-contact-info ph-sm">
                    <li><b><i class="color-primary mr-sm fa fa-envelope"></i></b> <?= $data['email']?></li>
                    <li><b><i class="color-primary mr-sm fa fa-phone"></i></b> <?= $data['phone']?></li>
                    <li><b><i class="color-primary mr-sm fa fa-globe"></i></b> <?= $data['city'].''?></li>
                    <br>
                </ul>
            </div>
        </div>
    
    </div>
    <div class="col-md-6 col-lg-8">
        <div class="row">
            <div class="col-md-6 " style="box-shadow:2px 3px 8px #ccc">
                <img src="../images/libraian/chat2.png" alt="" style = "width:100%">
            </div>
            <div class="col-md-6" style="box-shadow:2px 3px 8px #ccc">
                <img src="../images/libraian/chat3.png" alt="" style = "width:100%">
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editProfileModal" tabindex="-1" role="dialog" aria-labelledby="editProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProfileModalLabel">Edit Profile Information</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
        </div>
    </div>
</div>
<?php require_once 'footer.php' ?>
