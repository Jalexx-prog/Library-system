<?php

include_once('include/db.php');

function getUserData($userID, $con) {
    // Ensure $userID is safe for SQL use
    $userID = mysqli_real_escape_string($con, $userID);

    // Fetch user data from the database
    $query = "SELECT * FROM users WHERE id = '$userID'";
    $result = mysqli_query($con, $query);

    if (!$result) {
        die('Error executing query: ' . mysqli_error($con));
    }

    // Fetch the user data as an associative array
    $userData = mysqli_fetch_assoc($result);

    return $userData;
}

// Assuming you have a user ID, you can use it to fetch user data
$userID = 1; // Replace with the actual user ID
$userData = getUserData($userID, $con);

// Close the database connection (assuming it's opened in include/db.php)
mysqli_close($con);

?>

<!-- Rest of your code... -->
