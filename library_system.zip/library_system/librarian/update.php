
<!-- function siya para don sa pag uupdate ng book -->
<?php
include('../include/db.php');

if (isset($_POST['save-btn'])) {
    $id = $_GET['id']; // Get the book ID from the URL parameter
    $bookName = $_POST['book_name'];
    $bookAuthor = $_POST['book_author'];
    $bookQuantity = $_POST['book_quantity'];
    $bookAvailable = $_POST['book_available'];

    // Update the book in the database
    $sql = "UPDATE books SET 
            book_name = '$bookName', 
            book_author = '$bookAuthor', 
            book_quantity = '$bookQuantity', 
            book_available = '$bookAvailable' 
            WHERE id = '$id'";

    $result = mysqli_query($con, $sql);

    if ($result) {
        // magreredirect siya sa location na to
        header('location: managebook.php'); 
        exit();
    } else {
        $error = "Error updating book: " . mysqli_error($con);
    }
}


?>
