<?php
include('../include/db.php');

if (isset($_GET['id'])) {
    $id = base64_decode($_GET['id']);

    // Fetch book details
    $selectQuery = "SELECT * FROM `books` WHERE `id` = ?";
    $selectStmt = mysqli_prepare($con, $selectQuery);
    mysqli_stmt_bind_param($selectStmt, "i", $id);
    mysqli_stmt_execute($selectStmt);
    $result = mysqli_stmt_get_result($selectStmt);
    $data = mysqli_fetch_assoc($result);

    if ($data) {
        $insertQuery = "INSERT INTO `deleted_books` (id, book_name, book_image, book_author, book_quantity, book_available, date, librian_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $insertStmt = mysqli_prepare($con, $insertQuery);

        if ($insertStmt === false) {
            die('Error in preparing insert statement: ' . mysqli_error($con));
        }

        mysqli_stmt_bind_param($insertStmt, "isssiiss", $data['id'], $data['book_name'], $data['book_image'], $data['book_author'], $data['book_quantity'], $data['book_available'], $data['date'], $data['librian_name']);
        $insertResult = mysqli_stmt_execute($insertStmt);

        if ($insertResult) {
            // Delete book and its image from books table
            $deleteQuery = "DELETE FROM `books` WHERE `id` = ?";
            $deleteStmt = mysqli_prepare($con, $deleteQuery);

            if ($deleteStmt === false) {
                die('Error in preparing delete statement: ' . mysqli_error($con));
            }

            mysqli_stmt_bind_param($deleteStmt, "i", $id);
            $deleteResult = mysqli_stmt_execute($deleteStmt);

            if ($deleteResult) {
                $delete_image = "Delete image Successfully";
                header('location: managebook.php');
            } else {
                $not_dlt = "Not delete";
                header('location: managebook.php');
            }
        } else {
            $not_dlt = "Error in inserting data into deleted_books table";
            header('location: managebook.php');
        }
    } else {
        $not_dlt = "Invalid book ID";
        header('location: managebook.php');
    }
}
?>
