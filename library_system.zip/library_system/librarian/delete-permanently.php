<?php
require_once '../include/db.php';

if (isset($_GET['id'])) {
    $id = base64_decode($_GET['id']);

    // Fetch book details from deleted_books
    $selectQuery = "SELECT * FROM `deleted_books` WHERE `id` = ?";
    $selectStmt = mysqli_prepare($con, $selectQuery);
    mysqli_stmt_bind_param($selectStmt, "i", $id);
    mysqli_stmt_execute($selectStmt);
    $result = mysqli_stmt_get_result($selectStmt);
    $data = mysqli_fetch_assoc($result);

    if ($data) {
        // Delete book permanently from deleted_books table
        $deleteQuery = "DELETE FROM `deleted_books` WHERE `id` = ?";
        $deleteStmt = mysqli_prepare($con, $deleteQuery);

        if ($deleteStmt === false) {
            die('Error in preparing delete statement: ' . mysqli_error($con));
        }

        mysqli_stmt_bind_param($deleteStmt, "i", $id);
        $deleteResult = mysqli_stmt_execute($deleteStmt);

        if ($deleteResult) {
            $delete_permanently_message = "Book permanently deleted successfully";
            header('location: deleted_books.php');
        } else {
            $delete_permanently_error = "Error in permanently deleting book";
             header('location: deleted_books.php');
        }
    } else {
        $delete_permanently_error = "Invalid book ID";
         header('location: deleted_books.php');
    }
} else {
    header('location: managebook.php');
}
?>
