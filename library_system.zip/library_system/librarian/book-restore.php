<?php
require_once '../include/db.php';

if (isset($_GET['id'])) {
    $id = base64_decode($_GET['id']);

    
    $selectQuery = "SELECT * FROM `deleted_books` WHERE `id` = ?";
    $selectStmt = mysqli_prepare($con, $selectQuery);
    mysqli_stmt_bind_param($selectStmt, "i", $id);
    mysqli_stmt_execute($selectStmt);
    $result = mysqli_stmt_get_result($selectStmt);
    $data = mysqli_fetch_assoc($result);

    if ($data) {
        
        $insertQuery = "INSERT INTO `books` (id, book_name, book_author, book_image, book_quantity, book_available, date, librian_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $insertStmt = mysqli_prepare($con, $insertQuery);

        if ($insertStmt === false) {
            die('Error in preparing insert statement: ' . mysqli_error($con));
        }

        mysqli_stmt_bind_param($insertStmt, "isssiiis", $data['id'], $data['book_name'], $data['book_author'], $data['book_image'], $data['book_quantity'], $data['book_available'], $data['date'], $data['librian_name']);
        $insertResult = mysqli_stmt_execute($insertStmt);

        if ($insertResult) {
            // Delete book from deleted_books table
            $deleteQuery = "DELETE FROM `deleted_books` WHERE `id` = ?";
            $deleteStmt = mysqli_prepare($con, $deleteQuery);

            if ($deleteStmt === false) {
                die('Error in preparing delete statement: ' . mysqli_error($con));
            }

            mysqli_stmt_bind_param($deleteStmt, "i", $id);
            $deleteResult = mysqli_stmt_execute($deleteStmt);

            if ($deleteResult) {
                $restore_message = "Book restored successfully";
                header('location: managebook.php');
            } else {
                $restore_error = "Error in deleting book from deleted_books table";
                header('location: managebook.php');
            }
        } else {
            $restore_error = "Error in restoring book to books table";
            header('location: managebook.php');
        }
    } else {
        $restore_error = "Invalid book ID";
        header('location: managebook.php');
    }
} else {
    header('location: managebook.php');
}
?>
