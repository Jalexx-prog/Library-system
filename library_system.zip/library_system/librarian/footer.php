</div>
                <!--scroll to top-->
                <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
            </div>
        </div>
        <!--BASIC scripts-->
        <!-- ========================================================= -->
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="../assets/vendor/jquery/jquery-1.12.3.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="../assets/vendor/nano-scroller/nano-scroller.js"></script>
        <!--TEMPLATE scripts-->
        <!-- ========================================================= -->
        <script src="../assets/javascripts/template-script.min.js"></script>
        <script src="../assets/javascripts/template-init.min.js"></script>
        <!-- SECTION script and examples-->
        <!-- ========================================================= -->
        <!--Notification msj-->
        
        <!--morris chart-->
        <script src="../assets/vendor/chart-js/chart.min.js"></script>
        <!--Gallery with Magnific popup-->
        <script src="../assets/endor/magnific-popup/jquery.magnific-popup.min.js"></script>
        <!--Examples-->
        <script src="../assets/javascripts/examples/dashboard.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="https://cdn.lordicon.com/lordicon.js"></script>
<script>
    $(document).ready(function () {
        // Make an AJAX request to fetch all books
        $.ajax({
            type: 'GET',
            url: 'api.php',
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    // Loop through the books and update the table
                    $.each(response.books, function (index, book) {
                        var newRow = '<tr>' +
                            '<td class="text-left">' + book.book_name + '</td>' +
                            '<td>' + book.book_author + '</td>' +
                            '<td>' + book.book_quantity + '</td>' +
                            '<td>' + book.book_available + '</td>' +
                            '<td>' + book.librian_name + '</td>' +
                            '<td class="text-center"><img src="' + book.book_image + '" alt="" width="50px"></td>' +
                            '<td class="text-center">' +
                            '<a href="" class="btn btn-info btn-sm" data-toggle="modal" data-target="#book-' + index + '"><i class="fa fa-eye"></i></a>' +
                            '<a href="" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#bookedit-' + index + '"><i class="fa fa-pencil"></i></a>' +
                            '<a href="deleteimg.php?id=' + btoa(index) + '" class="btn btn-danger btn-sm dlt-btn" onclick="return confirm(' + "'Are you sure ?'" + ')"><i class="fa fa-trash"></i></a>' +
                            '</td>' +
                            '</tr>';

                        // Append the new row to the table
                        $('#basic-table tbody').append(newRow);

                        // Update modal details for each book
                        $('#book-' + index + ' .modal-title').text('Book Details - ' + book.book_name);
                        $('#book-' + index + ' .modal-body img').attr('src', book.book_image);
                        $('#book-' + index + ' .modal-body td:eq(1)').text(book.book_name);
                        $('#book-' + index + ' .modal-body td:eq(3)').text(book.book_author);
                        $('#book-' + index + ' .modal-body td:eq(5)').text(book.book_quantity);
                        $('#book-' + index + ' .modal-body td:eq(7)').text(book.book_available);
                        $('#book-' + index + ' .modal-body td:eq(9)').text(book.librian_name);
                        $('#book-' + index + ' .modal-body td:eq(11)').text(book.date);
                    });
                } else {
                    // Handle the error
                    console.error(response.message);
                }
            },
            error: function (xhr, status, error) {
                // Handle the AJAX error
                console.error(error);
            }
        });
    });
</script>



<script>
document.addEventListener("DOMContentLoaded", function() {
    // Fetch requests when the page is loaded
    fetch('api_fetch_requests.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Process the fetched data (requests)
                const requests = data.requests;

                // Example: Log the requests to the console
                console.log(requests);

                // TODO: Update the HTML to display the requests as needed

                // Example: Update a table with the fetched data
                const tableBody = document.querySelector('#basic-table tbody');
                tableBody.innerHTML = ''; // Clear existing rows

                requests.forEach(request => {
                    const row = `
                        <tr>
                            <td>${request.student_name}</td>
                            <td>${request.student_id}</td>
                            <td>${request.book_name}</td>
                            <td>
                                <a href="#" class="issue-book-btn" data-req-id="${request.id}" data-book-id="${request.book_id}">Issue Book</a>
                            </td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                });
            } else {
                // Handle error
                console.error('Error fetching requests:', data.message);
            }
        })
        .catch(error => console.error('Error:', error));
});
</script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('.update-btn').click(function() {
            var bookId = $(this).data('id');
            var bookName = prompt("Enter new book name:");

            if (bookName != null) {
                // Send an AJAX request to the update API
                $.ajax({
                    type: 'POST',
                    url: 'update_book_api.php',
                    data: {
                        id: bookId,
                        book_name: bookName
                        // Add other parameters as needed
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert(response.message);
                            // Reload the page or update the UI as needed
                            location.reload();
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function() {
                        alert('Error updating book');
                    }
                });
            }
        });
    });
</script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('.update-btn').click(function() {
            var bookId = $(this).data('id');
            var newBookName = prompt("Enter new book name:");

            if (newBookName !== null) {
                // Send an AJAX request to update the book name
                $.ajax({
                    type: 'POST',
                    url: 'update_book_api.php',  // Update the URL to your actual update API endpoint
                    data: {
                        id: bookId,
                        book_name: newBookName
                        // Add other parameters as needed
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert(response.message);
                            // Reload the page or update the UI as needed
                            location.reload();
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function() {
                        alert('Error updating book');
                    }
                });
            }
        });
    });
</script>




    </body>

</html>