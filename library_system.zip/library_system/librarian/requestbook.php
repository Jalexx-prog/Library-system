<?php include('header.php') ;
include('../include/db.php');
?>

<!-- content HEADER -->
<!-- ========================================================= -->
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            <li><a href="">Request Book</a></li>

        </ul>
    </div>
</div>    
<div class="row animated fadeInUp">
    <h4 class="section-subtitle"><b>Request Books Overview</b></h4>
    <div class="panel">
        <div class="panel-content">
            <div class="table-responsive">
                <table id="basic-table" class="data-table table table-striped nowrap table-hover table-bordered border" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Student Name</th>
                            <th>Student ID</th>
                            <th>Book Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        include('../include/db.php');
                        $sql = "SELECT * FROM `request_book` ORDER BY id DESC ";
                        $result =mysqli_query($con,$sql);
                        while($row = mysqli_fetch_assoc($result)){?>
                        <tr>
                            <td><?= $row['student_name']?></td>
                            <td><?= $row['student_id']?></td>
                            <td><?= $row['book_name']?></td>
                            <td>
                                <a href="requestbook.php?req_id=<?= $row['id']?>&book_id=<?= $row['book_id']?>">Issue Book</a>
                            </td>

                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
if (isset($_GET['req_id']) && isset($_GET['book_id'])) {
    $lib = $_SESSION['for_issue_book_page'];
    $req_id = $_GET['req_id'];
    $book_id = $_GET['book_id'];
    $date = date('m-d-Y');
    
    $sq = "SELECT students.id FROM students INNER JOIN request_book ON students.uid = request_book.student_id WHERE request_book.id = ?";
    $stmt = mysqli_prepare($con, $sq);
    mysqli_stmt_bind_param($stmt, "i", $req_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $ro = mysqli_fetch_assoc($result);
    
    if ($ro) {
        $std_id = $ro['id'];
        $sql = "INSERT INTO issue_book(student_id, book_id, lib_name, isssue_date) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($stmt, "iiss", $std_id, $book_id, $lib, $date);
        mysqli_stmt_execute($stmt);

        if ($stmt) {
            $sql = "UPDATE books SET book_available = book_available - 1 WHERE id = ?";
            $stmt = mysqli_prepare($con, $sql);
            mysqli_stmt_bind_param($stmt, "i", $book_id);
            mysqli_stmt_execute($stmt);

            $sql = "DELETE FROM request_book WHERE id = ?";
            $stmt = mysqli_prepare($con, $sql);
            mysqli_stmt_bind_param($stmt, "i", $req_id);
            mysqli_stmt_execute($stmt);

            if ($stmt) {
                echo '<script>alert("Request Book Successfully"); history.go(-1);</script>';
            } else {
                echo 'Error deleting request book record.';
            }
        } else {
            echo 'Error issuing the book.';
        }
    } else {
        echo 'User ID not found.';
    }
}
?>

<?php include('footer.php'); ?>