<?php
session_start();
if(isset($_SESSION['admin_success_id'])){
    header('location:index.php');
}
include('../include/db.php');
if(isset($_POST['btn']))
{
    $username = $_POST['username'];
    $password= $_POST['password'];
    
    $sql = "SELECT * FROM `libraian` WHERE `username` = '$username' AND `password` = '$password' ";
    $result = mysqli_query($con,$sql);
    $row_count = mysqli_num_rows($result);
    $admin_info = mysqli_fetch_assoc($result);

    if($row_count == 1){

        $_SESSION['admin_success_id'] = $admin_info['id'];
        header('location:index.php');

    }else{
        $input_error = "User name or Password doesnt match!!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/stylesheets/css/style1.css">
    <title>Document</title>
</head>
<body>
  
<div class="content">
  <div class="text">
    LIBRIAN
  </div>
  <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <div class="field">
      <span class="lordicon-icon">
      <lord-icon
      src="https://cdn.lordicon.com/zorvjzqh.json"
        trigger="hover"
        colors="primary:#08a88a,secondary:#08a88a"
        style="width:40px;height:50px">
    </lord-icon>
      </span>
      <input type="text" name="username" value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" required>
      <label>&nbsp&nbspUsername</label>
    </div>
    <div class="field">
      <span class="lordicon-icon">
        <lord-icon
        src="https://cdn.lordicon.com/ppsqwkvn.json"
          trigger="hover"
          style="width:40px; height:50px">
        </lord-icon>
      </span>
      <input type="password" name="password" required>
      <label>&nbsp&nbspPassword</label>
    </div>
    <?php if(!empty($input_error)) { ?>
        <div style="color: red;"><?php echo $input_error; ?></div>
    <?php } ?>
    <?php if(!empty($status_not_active)) { ?>
        <div style="color: red;"><?php echo $status_not_active; ?></div>
    <?php } ?>
    <div class="forgot-pass">
      <a href="#"><br></a>
    </div>
    <button class="btn btn-primary" name="btn">Sign in</button>
    <div class="sign-up">
      
      <a href="../index.php">Back</a>
    </div>
  </form>
</div>

<?php require_once 'footer.php' ?>
</body>
</html>
