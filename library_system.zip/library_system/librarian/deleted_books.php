<?php 
require_once 'header.php' 
?>

<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="#">Dashboard</a></li>
            <li><a href="">Manage Book</a></li>
        </ul>
    </div>
</div>    

<div class="row animated fadeInUp">
    <div class="col-12 col-sm-12 col-md-12">
        <h4 class="section-subtitle"><b>Deleted Books Overview</b></h4>

        <!-- Display success and error messages -->
        <?php  if(isset($delete_image)){?>
            <div class="alert alert-success alert-dismissible show" role="alert">
                <b><?= 'ddddddddddddddddddd' ?></b> 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php }?>

        <?php  if(isset($not_dlt)){?>
            <div class="alert alert-danger alert-dismissible show" role="alert">
                <b><?= $not_dlt ?></b> 
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php }?>

        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover table-bordered border" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Book Name</th>
                                <th>Book Author</th>
                                <th>Book Quantity</th>
                                <th>Book Available</th>
                                <th>Librarian</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php
                            include('../include/db.php');
                            $sql = "SELECT * FROM `deleted_books` ORDER BY `id` DESC ";
                            $result = mysqli_query($con, $sql);

                            while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <tr>
                                    <td class="text-left"><?= $row['book_name']?></td>
                                    <td><?= $row['book_author']?></td>
                                    <td><?= $row['book_quantity']?></td>
                                    <td><?= $row['book_available']?></td>
                                    <td><?= $row['librian_name']?></td>
                                    <td class="text-center"> <img src="../images/book/<?= $row['book_image']?>" alt="" width="50px"></td>
                                    <td class="text-center">
                                    <a href="delete-permanently.php?id=<?= base64_encode($row['id'])?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to permanently delete this book?')">
                                        <span class="icon">
                                        <lord-icon
                                                    src="https://cdn.lordicon.com/drxwpfop.json"
                                                    trigger="hover"
                                                    stroke="bold"
                                                    colors="primary:#000000,secondary:#000000"
                                                    style="width:15px;height:15px">
                                                </lord-icon>

                                        </span>
                                        </a>
                                        <a href="book-restore.php?id=<?= base64_encode($row['id'])?>" class="btn btn-success btn-sm" onclick="return confirm('Are you sure you want to restore this book?')">
                                        <span class="icon">
                                        <lord-icon
                                                    src="https://cdn.lordicon.com/zrkkrrpl.json"
                                                    trigger="hover"
                                                    stroke="bold"
                                                    colors="primary:#000000,secondary:#000000"
                                                    style="width:15px;height:15px">
                                                </lord-icon>

                                        </span>
                                        </a>
                                        
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
$sql = "SELECT * FROM deleted_books ORDER BY id DESC";
$res = mysqli_query($con, $sql);

while ($books = mysqli_fetch_assoc($res)) {
    ?>
    <div class="modal fade" id="book-<?= $books['id']?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
       
    </div>
<?php } ?>

<?php require_once 'footer.php' ?>
